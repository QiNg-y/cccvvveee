<?php
include_once 'connections/db.php';
$user->logout();

?>
